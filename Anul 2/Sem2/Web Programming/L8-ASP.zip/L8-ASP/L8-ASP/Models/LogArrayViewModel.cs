﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using L8_ASP.Entities;

namespace L8_ASP.Models {
    public class LogArrayViewModel {
        public List<Log> Logs { get; set; }
    }
}
