# Steering Comitee

![[Pasted image 20210526132137.png]]

The Steering Comitee dashboard allows the user to change the role of a selected user or access [[Assigning papers]] window to manage the reviewing process