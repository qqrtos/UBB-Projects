# Reviewer

![[Pasted image 20210526131816.png]]

In this windows, the user has a list of the papers he has access to for reviewing and a series of buttons to provide his evaluation for the selected paper
- Strong accept
- Accept
- Weak accept
- Borderline paper
- Weak reject
- Reject
- Strong Reject