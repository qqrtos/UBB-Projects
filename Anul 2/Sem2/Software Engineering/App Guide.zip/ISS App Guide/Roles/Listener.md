# Listener

![[Pasted image 20210526130713.png]]

A Listener is a role which any participant has at first excepting the Conference creator

In the Listener window, the user is able to see the conference details and has access to "Submit abstract" and "Add Full Paper Details" which will qualify him as an [[Author]]