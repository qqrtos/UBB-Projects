# Author

As an author, the user has to work with the following windows:
1. [[Submit Abstract]]
2. [[Add Full Paper]]