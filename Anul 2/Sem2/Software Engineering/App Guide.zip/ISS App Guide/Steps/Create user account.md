# Create user account
![[Pasted image 20210525215110.png]]

To create an account, the user must press the "Create Account" button in the main window and follow the next steps

![[Pasted image 20210525214849.png]]

### Steps

1. Type the new user data:
	1. username
		- ~validation rules
	2. password
		- ~validation rules
2. Press the "Create User" button to finish the account creation
3. [[Log in]]