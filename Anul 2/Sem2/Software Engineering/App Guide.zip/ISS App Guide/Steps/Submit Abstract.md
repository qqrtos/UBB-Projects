# Submit Abstract

![[Pasted image 20210526131414.png]]

In this window, the [[Author]] can submit details about his [[Paper]] prior to it's full submission