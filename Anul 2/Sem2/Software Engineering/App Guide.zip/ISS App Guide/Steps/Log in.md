# Log in

![[Pasted image 20210525215251.png]]

In this main window, the user has to type his credentials introduced at the [[Create user account]] step and then the main [[dashboard ]] is shown