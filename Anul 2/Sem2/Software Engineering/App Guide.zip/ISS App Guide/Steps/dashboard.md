# Dashboard

![[Pasted image 20210526122330.png]]

From the dashboard, the user can do the actions for managing the conferences

Depending on what the users choices in terms of creating and managing conferences and participation, [[restrictions]] in usage might be applied

In the dashboard, the user has the next options:
1. Create a conference by clicking on the "Create conference" button
	- Pressing this button will get you to the [[Create Conference]] window
2. Update a selected conference ( "Update selected" button)
	- Pressing this button will get you yo the [[Update conference]] window
3. Check out a selected conference ("View selected conference")
	- Depending on the role assignated to each user for a certain conference, this button will open windows accordingly
	1. [[Listener]]
	2. [[Reviewer]]
	3. [[Steering Comitee]]
1. Participiate in a conference by the "Participate" button