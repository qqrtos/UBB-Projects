# Update conference

![[Pasted image 20210526125132.png]]

Basically, the user has the exact same options as in the [[Create Conference]] window.