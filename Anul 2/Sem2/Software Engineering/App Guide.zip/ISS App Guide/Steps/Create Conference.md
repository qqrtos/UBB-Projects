# Creating a conference

![[Pasted image 20210526124749.png]]

Once the user gets to this step, he can choose the new conference's details and create the conference

After this step, the user has the ability to update the conference details by accessing the [[Update conference]] window