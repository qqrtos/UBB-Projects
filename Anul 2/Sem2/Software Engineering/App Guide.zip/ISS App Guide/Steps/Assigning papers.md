# Assigning papers

![[Pasted image 20210526132350.png]]

In this window the user has the ability to select papers and assign them to selected reviewers to start the reviewing process