# Add full paper

![[Pasted image 20210526131611.png]]

In this window, the user has the ability to provide the full [[Paper]] data so [[Reviewer]]s can continue with the process of handling the papers.