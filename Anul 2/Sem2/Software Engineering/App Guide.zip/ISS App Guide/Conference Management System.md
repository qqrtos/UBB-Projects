# Conference Management System


### Usage

The app is built to accomodate the workflows in creating and managing conferences

- User roles:
	- [[Steering Comitee]]
	-  [[Listener]]
	-  [[Reviewer]]
	-  [[Author]]

Users can have multiple roles, but will be subjected to a set of [[restrictions]] in terms of same-conference roles.

### Guided app usage

1. [[Create user account ]]
2. [[Log in]]
3. [[dashboard]]
4. User specific workflow
	~ Check the role pages to read about these