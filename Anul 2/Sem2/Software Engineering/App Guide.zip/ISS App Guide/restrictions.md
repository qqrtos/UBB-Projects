# Restrictions

### Usage constraints

1. Users shouldn't be able to use [[Reviewer]] and [[Author]] actions on the same paper