class Selector:
    def __init__(self):
        self._entityList = []

    def __iter__(self):
        self._current = 0
        return self

    def __next__(self):
        if self._current == len(self._entityList):
            raise StopIteration
        c = self._current
        self._current += 1
        return self._entityList[c]

    def __setitem__(self, key, value):
        self._entityList[key] = value

    def __getitem__(self, index):
        return self._entityList[index]

    def __delitem__(self, key):
        self._entityList.pop(key)

    def stoogeSort(self, low, high):
        if low >= high:
            return
        if self._entityList[low] > self._entityList[high]:
            t = self._entityList[low]
            self._entityList[low] = self._entityList[high]
            self._entityList[high] = t

        if high - low + 1 > 2:
            t = (high - low + 1) // 3
            self.stoogeSort(low, high - t)
            self.stoogeSort(low + t, high)
            self.stoogeSort(low, high - t)

    def filter(self, rentals, client, movie):
        for rental in rentals:
            if self._key(rental, client, movie) == True:
                self._entityList.append(rental)

    def _key(self, rental, client, movie):
        if client is not None and rental.clientID != client.ID:
            return False
        if movie is not None and rental.movieID != movie.ID:
            return False
        return True

