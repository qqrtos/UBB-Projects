from Repos.repository import Repository
import pickle
import json


class TextFileRepository(Repository):
    def __init__(self, file, entity):
        super().__init__()
        self._entity = entity
        self.file = file
        self._loadFile()

    def _loadFile(self):
        with open(self.file, "r") as f:
            lines = f.readlines()
            for line in lines:
                tokens = line.strip().split(',')
                element = self._entity(*tokens)
                self.addElement(element)
            f.close()

    def _saveFile(self):
        with open(self.file, "w") as f:
            for e in self.getRepoList():
                f.write(str(e))
            f.close()

    def addElement(self, element):
        super().addElement(element)
        self._saveFile()

    def removeElement(self, ID):
        super().removeElement(ID)
        self._saveFile()

    def updateElement(self, ID, newElement):
        super().updateElement(ID, newElement)
        self._saveFile()


class PickleRepository(TextFileRepository):
    def _saveFile(self):
        with open(self.file, 'wb') as f:
            pickle.dump(self._entityList, f)
            f.close()

    def _loadFile(self):
        with open(self.file, 'rb') as f:
            self._entityList = pickle.load(f)
            f.close()

    def addElement(self, element):
        super().addElement(element)
        self._saveFile()

    def removeElement(self, ID):
        super().removeElement(ID)
        self._saveFile()

    def updateElement(self, ID, newElement):
        super().updateElement(ID, newElement)
        self._saveFile()


class JSONRepository(TextFileRepository):
    def _getDictFromCustomEntity(self, obj):
        # A function takes in a custom object and returns a dictionary representation of the object.
        obj_dict = {
            "__class__": obj.__class__.__name__,
            "__module__": obj.__module__
        }

        # Fill the dictionary with object properties
        obj_dict.update(obj.__dict__)
        obj_dict.pop('_ID')  # Delete the _ID parameter because it's randomly generated.
        return obj_dict

    def _dict_to_obj(self, our_dict):
        """
        Function that takes in a dict and returns a custom object associated with the dict.
        This function makes use of __module__ and __class__ in the dictionary to know which object type to create.
        """
        if "__class__" in our_dict:
            class_name = our_dict.pop(
                "__class__")  # Pop ensures we remove metadata from the dict to leave only the instance arguments
            module_name = our_dict.pop("__module__")  # Get the module name from the dict and import it

            # Use the built in __import__ function since the module name is not yet known at runtime
            module = __import__(module_name)
            # Get the class from the module
            class_ = getattr(module, class_name)

            # Put the parameters of __class__ into attributes.
            attributes = []
            for k in our_dict.keys():
                attributes.append(our_dict[k])
            obj = class_(*attributes)
        else:
            obj = our_dict
        return obj

    def _saveFile(self):
        elements = []
        with open(self.file, 'w') as f:
            for elem in self._entityList:
                elements.append(self._getDictFromCustomEntity(elem))
            json.dump(elements, f)
            f.close()

    def _loadFile(self):
        with open(self.file, 'r') as f:
            self._entityList = json.load(f, object_hook=self._dict_to_obj)
            f.close()

    def addElement(self, element):
        super().addElement(element)
        self._saveFile()

    def removeElement(self, ID):
        super().removeElement(ID)
        self._saveFile()

    def updateElement(self, ID, newElement):
        super().updateElement(ID, newElement)
        self._saveFile()
