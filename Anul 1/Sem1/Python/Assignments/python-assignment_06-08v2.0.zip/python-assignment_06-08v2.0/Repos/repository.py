from selector import Selector

class IDError(Exception):
    def __init__(self, msg):
        super().__init__(msg)



class Repository(Selector):
    def __init__(self):
        super().__init__()

    def __len__(self):
        return len(self._entityList)

    def getRepoList(self):
        '''
        :return: Returns a copy of the list of entities
        '''
        return self._entityList[:]

    def IDinRepo(self, ID):
        '''
        Checks whether an ID is already in the repository
        :return: The index of the element with ID if it exists and -1 otherwise
        '''
        for i in range(len(self._entityList)):
            if self._entityList[i].ID == ID:
                return i
        return -1

    def addElement(self, element):
        '''
        Adds an element to the list of entities
        :param element: The element to be added
        :return: -
        '''
        self._entityList.append(element)

    def removeElement(self, ID):
        '''
        Remove an element with the corresponding ID
        :return: -
        '''
        for e in self._entityList:
            if e.ID == ID:
                self._entityList.remove(e)
                break

    def updateElement(self, ID, newElement):
        '''
        Updates the element with the given ID.
        :param newElement: the entity with updated values
        :return: -
        '''
        for i in range(len(self._entityList)):
            if self._entityList[i].ID == ID:
                self._entityList[i] = newElement
                self._entityList[i]._ID = ID
                break
