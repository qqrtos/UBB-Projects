from AppStart import *
from Repos.repository import IDError

'''
    DATE IS IN THE FORMAT YYYY-MM-DD

    datetime.datetime.strptime('12-03-2019','%Y-%m-%d').date()        <- conversion form str to date
'''


class UserInterface:
    def __init__(self, appStarter):
        self._clientService = appStarter.clientService
        self._movieService = appStarter.movieService
        self._rentalService = appStarter.rentalService
        self._undoService = appStarter.undoService

    @property
    def ClientService(self):
        return self._clientService

    @property
    def MovieService(self):
        return self._movieService

    @property
    def RentalService(self):
        return self._rentalService

    @staticmethod
    def printOptions():
        print("\n1. Manage clients list.")
        print("2. Manage movies list.")
        print("3. List all clients.")
        print("4. List all movies.")
        print("5. List rentals.")
        print("6. Rent a movie.")
        print("7. Return a movie.")
        print("8. Search client.")
        print("9. Search movie.")
        print("10. Rental statistics.")
        print("11. Undo")
        print("12. Redo")
        print("x. Exit.\n")

    def _printMoviesOptions(self):
        print("\t1. Add a movie.")
        print("\t2. Remove a movie.")
        print("\t3. Update a movie's info.")
        print("\t4. Back.")

    def _printClientsOptions(self):
        print("\t1. Add a client.")
        print("\t2. Remove a client.")
        print("\t3. Update a client's info.")
        print("\t4. Back.")

    def addClient_UI(self):
        '''
        Reads the user's input and adds ads a client to Repo.
        :return: -
        '''
        name = input("Name: ")
        self.ClientService.addClient(name)

    def addMovie_UI(self):
        title = input("Title: ")
        desc = input("Description: ")
        gen = input("Genre: ")
        self.MovieService.addMovie(title, desc, gen)

    def removeClient_UI(self):
        ID = input("ID: ")
        self.ClientService.removeClient(ID)

    def removeMovie_UI(self):
        ID = input("ID: ")
        self.MovieService.removeMovie(ID)

    def updateClient_UI(self):
        ID = input("ID: ")
        name = input("Name: ")
        self.ClientService.updateClient(ID, name)

    def updateMovie_UI(self):
        ID = input("ID: ")
        title = input("Title: ")
        desc = input("Description: ")
        gen = input("Genre: ")
        self.MovieService.updateMovie(ID, title, desc, gen)

    def showClients(self):
        clients = self.ClientService.getListOfClients()
        for c in clients:
            print(('ID: ' + str(c.ID)).ljust(15) + ('Name: ' + c.clientName))

    def showMovies(self):
        movies = self.MovieService.getListOfMovies()
        for m in movies:
            print(('ID: ' + str(m.ID)).ljust(15) + ('Title: ' + m.movieTitle).ljust(30) +
                  ('Description: ' + m.movieDescription).ljust(30) +
                  ('Genre: ' + m.movieGenre))

    def showRentals(self):
        rentals = self.RentalService.getListOfRentals()
        for r in rentals:
            print(('ID: ' + str(r.ID)).ljust(15) + ('Movie ID: ' + r.movieID).ljust(20) +
                  ('Client ID: ' + r.clientID).ljust(25) + 'Rented Date: ' + str(r.rentedDate).ljust(20) +
                  'Due Date: ' + str(r.dueDate))

    def rentMovie(self):
        clientID = input("Client ID: ")
        movieID = input("Movie ID: ")
        todayDate = input("Today's date (YYYY-MM-DD): ")
        dueDate = input("Return date (YYYY-MM-DD): ")
        self.RentalService.rentMovie(clientID, movieID, todayDate, dueDate)

    def returnMovie(self):
        rentalID = input("Rental ID: ")
        self.RentalService.returnMovie(rentalID)

    def searchClient(self):
        text = input("Search: ")
        matchingClients = self.ClientService.searchClientsList(text)
        for c in matchingClients:
            print("ID: " + c.ID, "Name: " + c.clientName)

    def searchMovie(self):
        text = input("Search: ")
        matchingMovies = self.MovieService.searchMoviesList(text)
        for m in matchingMovies:
            print(("ID: " + m.ID).ljust(15), ("Title: " + m.movieTitle).ljust(15), ('Genre: ' + m.movieGenre).ljust(15))

    def showStatistics(self):
        print("Most rented movies. The list of movies, sorted by the number of times they were rented")
        print("Days".ljust(10) + "Movie".ljust(30))
        for m in self.RentalService.mostOftenRentedMovies():
            print(m)
        print("-" * 50)

        print("\n\nMost active clients. The list of clients, sorted by the number of rentals")
        print("Times".ljust(10) + "Client".ljust(30))
        for c in self.RentalService.mostActiveClients():
            print(c)
        print("-" * 50)

        print("\n\nLate rentals. The list of late rentals, sorted by the due date")
        print("Due date".ljust(15) + "Rental ID".ljust(15))
        for lr in self.RentalService.lateRentals():
            print(lr)
        print("-" * 50)

    def undo(self):
        self._undoService.undo()

    def redo(self):
        self._undoService.redo()

    def start(self):
        clientsCommands = {'1': self.addClient_UI, '2': self.removeClient_UI, '3': self.updateClient_UI}
        moviesCommands = {'1': self.addMovie_UI, '2': self.removeMovie_UI, '3': self.updateMovie_UI}
        generalCommands = {'3': self.showClients, '4': self.showMovies, '5': self.showRentals, '6': self.rentMovie,
                           '7': self.returnMovie, '8': self.searchClient, '9': self.searchMovie,
                           '10': self.showStatistics, '11': self.undo, '12': self.redo}
        UserInterface.printOptions()
        while True:
            opt = input("Option:> ")
            if opt == '1':
                self._printClientsOptions()
                opt2 = input("\tClient option:> ")
                if opt2 in clientsCommands.keys():
                    try:
                        clientsCommands[opt2]()
                    except domain.ClientError as ce:
                        print(ce)
                    except IDError as IDerr:
                        print(IDerr)
            elif opt == '2':
                self._printMoviesOptions()
                opt2 = input("\tMovie option:> ")
                if opt2 in moviesCommands.keys():
                    try:
                        moviesCommands[opt2]()
                    except domain.MovieError as me:
                        print(me)
                    except IDError as IDerr:
                        print(IDerr)
            elif opt in generalCommands.keys():
                try:
                    generalCommands[opt]()
                except domain.MovieError as me:
                    print(me)
                except domain.ClientError as ce:
                    print(ce)
                except domain.RentalError as re:
                    print(re)
                except IDError as IDerr:
                    print(IDerr)
                except service.UndoRedoError as URerror:
                    print(URerror)
            elif opt == 'x':
                break
            else:
                print("Invalid command!")


settings = Settings('settings.properties')
startApp = StartApplication(settings)
UI = UserInterface(startApp)
UI.start()
