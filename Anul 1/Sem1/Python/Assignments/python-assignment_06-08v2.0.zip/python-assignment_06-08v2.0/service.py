import domain
from Repos import repository


class MovieRentalCount:
    def __init__(self, movie, rentalCount):
        self._movie = movie
        self.__rentals = rentalCount

    @property
    def movie(self):
        return self._movie

    def getRentalCount(self):
        return self.__rentals

    def __lt__(self, other):
        return self.getRentalCount() > other.getRentalCount()

    def __str__(self):
        return str(self.getRentalCount()).ljust(10) + " for movie " + str(self.movie).ljust(30)


class ClientRentalCount:
    def __init__(self, client, rentalCount):
        self._client = client
        self.__rentals = rentalCount

    @property
    def client(self):
        return self._client

    def getRentalCount(self):
        return self.__rentals

    def __lt__(self, other):
        return self.getRentalCount() > other.getRentalCount()

    def __str__(self):
        return str(self.getRentalCount()).ljust(10) + " for client " + str(self.client).ljust(30)


class LateRentals:
    def __init__(self, rental):
        self._rental = rental

    @property
    def rental(self):
        return self._rental

    def __str__(self):
        return (str(self._rental.dueDate).ljust(15) + self._rental.ID.ljust(15))

    def __lt__(self, other):
        return self._rental.dueDate > other._rental.dueDate


class ClientService:
    def __init__(self, clientsRepo, rentalRepo, undoService, rentalService):
        self._clientsRepository = clientsRepo
        self._rentalRepository = rentalRepo
        self._undoService = undoService
        self._rentalService = rentalService

    def getListOfClients(self):
        return self._clientsRepository.getRepoList()

    def hasRentedMovies(self, clientID):
        for r in self._rentalRepository.getRepoList():
            if r.clientID == clientID:
                return r
        return None

    def addClient(self, name, ID=None):
        '''
        Creates and adds a valid client to Repo
        :param name: client specifications
        :return: -
        '''
        client = domain.Client(name)
        if ID is not None:
            client._ID = ID
        undo = [FunctionCall(self.removeClient, client.ID)]
        redo = [FunctionCall(self.addClient, client.clientName, ID)]
        operation = Operation(undo, redo)
        self._undoService.recordOperation(operation)
        self._clientsRepository.addElement(client)

    def removeClient(self, ID):
        index = self._clientsRepository.IDinRepo(ID)
        if index == -1:
            raise repository.IDError("Client ID inexistent.")
        undo = [FunctionCall(self.addClient, self._clientsRepository[index].clientName, ID)]
        redo = [FunctionCall(self.removeClient, self._clientsRepository[index].ID)]
        r = self.hasRentedMovies(ID)
        while r is not None:
            undo.append(
                FunctionCall(self._rentalService.rentMovie, ID, r.movieID, str(r.rentedDate), str(r.dueDate), r.ID))
            redo.append(FunctionCall(self._rentalService.returnMovie, r.ID))
            self._rentalService.returnMovie(r.ID)
            r = self.hasRentedMovies(ID)
        operation = Operation(undo, redo)
        self._undoService.recordOperation(operation)
        # self._rentalRepository.removeElement(self._clientsRepository[index].ID)
        self._clientsRepository.removeElement(ID)

    def updateClient(self, ID, name):
        index = self._clientsRepository.IDinRepo(ID)
        if index == -1:
            raise repository.IDError("ID is not in clients repo.")
        c = domain.Client(name)
        undo = [FunctionCall(self.updateClient, ID, self._clientsRepository[index].clientName)]
        redo = [FunctionCall(self.updateClient, ID, name)]
        operation = Operation(undo, redo)
        self._undoService.recordOperation(operation)
        self._clientsRepository.updateElement(ID, c)

    def searchClientsList(self, text):
        matchingClients = []
        text = text.upper()
        for i in range(len(self._clientsRepository)):
            if text in self._clientsRepository[i].ID.upper() or text in self._clientsRepository[i].clientName.upper():
                matchingClients.append(self._clientsRepository[i])
        return matchingClients


class MovieService:
    def __init__(self, movieRepo, rentalRepo, undoService, rentalService):
        self._rentalRepository = rentalRepo
        self._moviesRepository = movieRepo
        self._undoService = undoService
        self._rentalService = rentalService

    def getListOfMovies(self):
        return self._moviesRepository.getRepoList()

    def hasBeenRented(self, movieID):
        for r in self._rentalRepository.getRepoList():
            if r.movieID == movieID:
                return r
        return None

    def addMovie(self, title, description, genre, ID=None):
        '''
        Creates and adds a valid movie to Repo
        :param ID, title, description, genre: movie details
        :return: -
        '''
        movie = domain.Movie(title, description, genre)
        if ID is not None:
            movie._ID = ID
        undo = [FunctionCall(self.removeMovie, movie.ID)]
        redo = [FunctionCall(self.addMovie, movie.movieTitle, movie.movieDescription, movie.movieGenre)]
        operation = Operation(undo, redo)
        self._undoService.recordOperation(operation)
        self._moviesRepository.addElement(movie)

    def removeMovie(self, ID):
        index = self._moviesRepository.IDinRepo(ID)
        if index == -1:
            raise repository.IDError("Movie ID inexistent.")
        undo = [FunctionCall(self.addMovie, self._moviesRepository[index].movieTitle,
                             self._moviesRepository[index].movieDescription, self._moviesRepository[index].movieGenre,
                             ID)]
        redo = [FunctionCall(self.removeMovie, ID)]
        r = self.hasBeenRented(ID)
        while r is not None:
            undo.append(
                FunctionCall(self._rentalService.rentMovie, r.clientID, ID, str(r.rentedDate), str(r.dueDate), r.ID))
            redo.append(FunctionCall(self._rentalService.returnMovie, r.ID))
            self._rentalService.returnMovie(r.ID)
            r = self.hasBeenRented(ID)
        operation = Operation(undo, redo)
        self._undoService.recordOperation(operation)
        # self._rentalRepository.removeElement(self._rentalRepository[index].ID)
        self._moviesRepository.removeElement(ID)

    def updateMovie(self, ID, title, desc, genre):
        index = self._moviesRepository.IDinRepo(ID)
        if index == -1:
            raise repository.IDError("ID is not in movies repo.")
        m = domain.Movie(title, desc, genre)
        undo = [FunctionCall(self.updateMovie, self._moviesRepository[index].movieTitle,
                             self._moviesRepository[index].movieDescription, self._moviesRepository[index].movieGenre)]
        redo = [FunctionCall(self.updateMovie, ID, title, desc, genre)]
        operation = Operation(undo, redo)
        self._undoService.recordOperation(operation)
        self._moviesRepository.updateElement(m)

    def searchMoviesList(self, text):
        matchingMovies = []
        text = text.upper()
        for i in range(len(self._moviesRepository)):
            if text in self._moviesRepository[i].ID.upper() or text in self._moviesRepository[
                i].movieTitle.upper() or text in self._moviesRepository[i].movieDescription.upper() or text in \
                    self._moviesRepository[i].movieGenre.upper():
                matchingMovies.append(self._moviesRepository[i])
        return matchingMovies


class RentalService:
    def __init__(self, rentalRepo, clientsRepo, moviesRepo):
        self._rentalRepository = rentalRepo
        self._moviesRepository = moviesRepo
        self._clientsRepository = clientsRepo
        self.__rentalHistory = []

    def getListOfRentals(self):
        return self._rentalRepository.getRepoList()

    def rentMovie(self, client_id, movie_id, todayDate, dueDate, rentalID=None):
        if self._moviesRepository.IDinRepo(movie_id) == -1:
            raise domain.RentalError("Chosen movie is not in the repository.")
        if self._clientsRepository.IDinRepo(client_id) == -1:
            raise domain.RentalError("Chosen client is not in the repository.")
        rentals = self.getListOfRentals()
        r = domain.Rental(movie_id, client_id, todayDate, dueDate)
        if rentalID is not None:
            r._ID = rentalID
        if r.rentedDate > r.dueDate:
            raise domain.RentalError("Rented date can't be lower than return date.")
        for element in rentals:
            if element.movieID == movie_id:
                raise domain.RentalError("Movie already rented.")
            elif element.clientID == client_id and r.rentedDate > element.dueDate:
                raise domain.RentalError("Client has a rented movie with a passed due date.")
        if r not in self.__rentalHistory:
            self.__rentalHistory.append(r)
        self._rentalRepository.addElement(r)

    def returnMovie(self, rentalID):
        if self._rentalRepository.IDinRepo(rentalID) == -1:
            raise repository.IDError("")
        self._rentalRepository.removeElement(rentalID)

    def filterRentals(self, client, movie):
        result = repository.Repository()
        result.filter(self.__rentalHistory, client, movie)
        # for rental in self.__rentalHistory:
        #     if client != None and rental.clientID != client.ID:
        #         continue
        #     if movie != None and rental.movieID != movie.ID:
        #         continue
        #     result.append(rental)
        return result._entityList

    def mostOftenRentedMovies(self):
        result = {}
        for movie in self._moviesRepository.getRepoList():
            if movie not in result.keys():
                result[movie] = 0
            rentals = self.filterRentals(None, movie)
            for r in rentals:
                result[movie] += len(r)

        dtoList = []
        for movie in result.keys():
            dtoList.append(MovieRentalCount(movie, result[movie]))

        dtoList.sort()
        return dtoList

    def mostActiveClients(self):
        result = {}
        for client in self._clientsRepository.getRepoList():
            if client not in result.keys():
                result[client] = 0
            rentals = self.filterRentals(client, None)
            for r in rentals:
                result[client] += 1

        dtoList = []
        for client in result.keys():
            dtoList.append(ClientRentalCount(client, result[client]))

        dtoList.sort()
        return dtoList

    def lateRentals(self):
        lateRentalsList = repository.Repository()
        for rental in self._rentalRepository.getRepoList():
            if rental.returnedDate is None:
                lateRentalsList._entityList.append(LateRentals(rental))
        lateRentalsList.stoogeSort(0, len(lateRentalsList) - 1)
        return lateRentalsList


class FunctionCall:
    def __init__(self, function, *params):
        self._functionName = function
        self._params = params

    def call(self):
        self._functionName(*self._params)


class Operation:
    def __init__(self, undo, redo):
        self._undo = undo
        self._redo = redo

    def undo(self):
        for u in self._undo:
            u.call()

    def redo(self):
        for r in self._redo:
            r.call()


class UndoRedoError(Exception):
    def __init__(self, msg=""):
        self._msg = msg


class UndoService:
    def __init__(self):
        self._history = []
        self._index = 0

    def recordOperation(self, operation):
        self._history.append(operation)
        self._index += 1

    def undo(self):
        if self._index == 0:
            raise UndoRedoError("No more undo's.")
        self._history[self._index - 1].undo()
        self._index -= 1

    def redo(self):
        if self._index == len(self._history):
            raise UndoRedoError("No more redo's.")
        self._history[self._index - 1].redo()
        self._index += 1
