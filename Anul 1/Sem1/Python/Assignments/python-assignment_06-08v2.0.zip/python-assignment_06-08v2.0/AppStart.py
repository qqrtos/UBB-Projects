import service
import domain
import random
from Repos.repository import Repository
from Repos.TextRepo import TextFileRepository, PickleRepository, JSONRepository
import configparser


def init_MoviesList():
    movieTitles = ['Titanic', 'Star Wars', 'The Lobster', 'Sharknado', 'Shutter Island']
    movieDescriptions = ['Nice movie', '10/10 would watch it again', 'Generic description', 'This was awful',
                         'It was alright']
    movieGenres = ['comedy', 'action', 'romance', 'thriller', 'horror']
    moviesList = []
    l = len(movieTitles)
    for i in range(l):
        randomTitle = random.randint(0, len(movieTitles) - 1)
        randomDesc = random.randint(0, len(movieDescriptions) - 1)
        randomGenre = random.randint(0, len(movieGenres) - 1)
        movie = domain.Movie(movieTitles[randomTitle], movieDescriptions[randomDesc], movieGenres[randomGenre])
        moviesList.append(movie)
        movieTitles.remove(movieTitles[randomTitle])
        movieDescriptions.remove(movieDescriptions[randomDesc])
        movieGenres.remove(movieGenres[randomGenre])
    return moviesList


def init_ClientsList():
    clientNames = ['John', 'Trevor', 'Tyrone', 'Sara', 'Britney']
    l = len(clientNames)
    clientsList = []
    for i in range(l):
        randomName = random.randint(0, len(clientNames) - 1)
        client = domain.Client(clientNames[randomName])
        clientsList.append(client)
        clientNames.remove(clientNames[randomName])
    return clientsList


def randomDate(minYear, maxYear):
    year = random.randint(minYear, maxYear - 1)
    month = random.randint(1, 12)
    day = random.randint(1, 28)
    return (year, month, day)


def init_RentalList(rentalService, movieRepo, clientRepo):
    movies = movieRepo.getRepoList()
    clients = clientRepo.getRepoList()
    indexes = [0, 1, 2, 3, 4]
    for i in range(3):
        r = random.choice(indexes)
        rentalDateTuple = randomDate(2010, 2019)
        dueDateTuple = randomDate(rentalDateTuple[0] + 4, 2023)

        rentalDate = str(rentalDateTuple[0]) + '-' + str(rentalDateTuple[1]) + '-' + str(rentalDateTuple[2])
        dueDate = str(dueDateTuple[0]) + '-' + str(dueDateTuple[1]) + '-' + str(dueDateTuple[2])

        indexes.remove(r)
        rentalService.rentMovie(clients[r].ID, movies[r].ID, rentalDate, dueDate)


class Settings:
    def __init__(self, settingsFile):
        self._settingsFile = settingsFile

    @property
    def repoType(self):
        config = configparser.RawConfigParser()
        config.read(self._settingsFile)
        return config.get('Repository', 'repository')

    @property
    def clientsFile(self):
        config = configparser.RawConfigParser()
        config.read(self._settingsFile)
        return config.get('Repository', 'clients')

    @property
    def moviesFile(self):
        config = configparser.RawConfigParser()
        config.read(self._settingsFile)
        return config.get('Repository', 'movies')


class StartApplication:
    def __init__(self, settings):
        # with open('Repos\clients.json', 'w') as f:
        #     for element in init_ClientsList():
        #         json.dump(getDictFromCustomEntity(element), f)
        #     f.close()
        # with open('Repos\movies.json', 'w') as f:
        #     for element in init_MoviesList():
        #         json.dump(getDictFromCustomEntity(element), f)
        #     f.close()

        if settings.repoType == 'inmemory':
            self._repoMovies = Repository()
            self._repoMovies._entityList = init_MoviesList()
            self._repoClients = Repository()
            self._repoClients._entityList = init_ClientsList()
        elif settings.repoType == 'jsonfile':
            self._repoMovies = JSONRepository(settings.moviesFile, domain.Movie)
            self._repoClients = JSONRepository(settings.clientsFile, domain.Client)
        elif settings.repoType == 'binaryfile':
            self._repoMovies = PickleRepository(settings.moviesFile, domain.Movie)
            self._repoClients = PickleRepository(settings.clientsFile, domain.Client)
        elif settings.repoType == 'textfile':
            self._repoMovies = TextFileRepository(settings.moviesFile, domain.Movie)
            self._repoClients = TextFileRepository(settings.clientsFile, domain.Client)
        else:
            raise Exception("settings.properties is wrong.")

        self._undoService = service.UndoService()
        self._repoRentals = Repository()
        self._rentalService = service.RentalService(self.repoRentals, self.repoClients, self.repoMovies)
        self._clientService = service.ClientService(self.repoClients, self.repoRentals, self.undoService,
                                                    self.rentalService)
        self._movieService = service.MovieService(self.repoMovies, self.repoRentals, self.undoService,
                                                  self.rentalService)
        init_RentalList(self._rentalService, self._repoMovies, self._repoClients)

    @property
    def repoMovies(self):
        return self._repoMovies

    @property
    def repoClients(self):
        return self._repoClients

    @property
    def repoRentals(self):
        return self._repoRentals

    @property
    def movieService(self):
        return self._movieService

    @property
    def clientService(self):
        return self._clientService

    @property
    def rentalService(self):
        return self._rentalService

    @property
    def undoService(self):
        return self._undoService
