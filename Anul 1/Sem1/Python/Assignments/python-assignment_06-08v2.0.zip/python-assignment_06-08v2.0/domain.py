from datetime import datetime
import random
import string

'''
 Movie: <movieId>, <title>, <description>, <genre>.
 Client: <clientId>, <name>.
 Rental: <rentalID>, <movieId>, <clientId>, <rented date>, <due date>, <returned date>.
'''


class ClientError(Exception):
    def __init__(self, errorMessage):
        super().__init__(errorMessage)


def generateRandomID():
    return ''.join([random.choice(string.ascii_letters + string.digits + '-_') for _ in range(5)])


class Client:
    def __init__(self, name):
        self._ID = generateRandomID()
        self.clientName = name

    @property
    def ID(self):
        return self._ID

    @property
    def clientName(self):
        return self._clientName

    @clientName.setter
    def clientName(self, name):
        if len(name) != 0:
            self._clientName = name
        else:
            raise ClientError("Name can't be empty.")

    def __str__(self):
        return (self.clientName+'\n')


class MovieError(Exception):
    def __init__(self, errorMessage):
        super().__init__(errorMessage)


class Movie:
    def __init__(self, title, desc, genre):
        self._ID = generateRandomID()
        self.movieTitle = title
        self.movieDescription = desc
        self.movieGenre = genre

    @property
    def ID(self):
        return self._ID

    @property
    def movieTitle(self):
        return self._movieTitle

    @movieTitle.setter
    def movieTitle(self, title):
        if len(title) > 0:
            self._movieTitle = title
        else:
            raise MovieError("Title can't be empty.")

    @property
    def movieDescription(self):
        return self._movieDescription

    @movieDescription.setter
    def movieDescription(self, desc):
        if len(desc) > 0:
            self._movieDescription = desc
        else:
            raise MovieError("Description can't be empty.")

    @property
    def movieGenre(self):
        return self._movieGenre

    @movieGenre.setter
    def movieGenre(self, genre):
        if len(genre) > 0:
            self._movieGenre = genre
        else:
            raise MovieError("Genre can't be empty.")

    def __str__(self):
        return (self.movieTitle +','+ self.movieDescription + ','+self.movieGenre+'\n')


class RentalError(Exception):
    def __init__(self, errorMessage):
        super().__init__(errorMessage)


class Rental:
    def __init__(self, movieID, clientID, rentedDate, dueDate):
        self._ID = generateRandomID()
        self._movieID = movieID
        self._clientID = clientID
        self.rentedDate = rentedDate
        self.dueDate = dueDate
        self._returnedDate = None

    @property
    def ID(self):
        return self._ID

    @property
    def movieID(self):
        return self._movieID

    @property
    def clientID(self):
        return self._clientID

    @property
    def rentedDate(self):
        return self._rentedDate

    @rentedDate.setter
    def rentedDate(self, d):
        try:
            #    datetime.datetime.strptime(d, '%Y-%m-%d').date()
            da = datetime.strptime(d, '%Y-%m-%d').date()
            # da = d.format(date)
            self._rentedDate = da
        except:
            raise RentalError("Date provided in an invalid format")

    @property
    def dueDate(self):
        return self._dueDate

    @dueDate.setter
    def dueDate(self, d):
        try:
            da = datetime.strptime(d, '%Y-%m-%d').date()
            self._dueDate = da
        except:
            raise RentalError("Date provided in an invalid format")

    @property
    def returnedDate(self):
        return self._returnedDate

    @returnedDate.setter
    def returnedDate(self, d):
        try:
            da = datetime.strptime(d, '%Y-%m-%d').date()
            self._returnedDate = da
        except:
            raise RentalError("Date provided in an invalid format")

    def __len__(self):
        return (self.dueDate - self.rentedDate).days + 1
