import unittest
from domain import *
from Repos.repository import *
import datetime


class TestDomain(unittest.TestCase):
    def test_RandomID(self):
        ids = []
        for i in range(3000):
            currentID = generateRandomID()
            self.assertNotIn(currentID, ids)
            ids.append(currentID)

    def test_Client(self):
        c = Client('Ion Bodor')
        self.assertEqual(c.clientName, 'Ion Bodor')
        with self.assertRaises(ClientError):
            c = Client('')

    def test_Movies(self):
        m = Movie('Pe aripile corbului', 'E misto', 'Poezie')
        self.assertEqual(m.movieTitle, 'Pe aripile corbului')
        self.assertEqual(m.movieDescription, 'E misto')
        self.assertEqual(m.movieGenre, 'Poezie')
        with self.assertRaises(MovieError):
            m = Movie('asd', 'asc', '')

    def test_Rental(self):
        # print(datetime.strptime('2016-02-13', '%Y-%m-%d').date())
        r = Rental('12', '3', '2016-02-24', '1001-12-03')
        self.assertEqual(r.movieID, '12') and self.assertEqual(r.clientID, '3')
        self.assertEqual(r.rentedDate, datetime.date(2016, 2, 24)) and self.assertEqual(r.dueDate,
                                                                                        datetime.date(1001, 12, 3))
        self.assertEqual(r.returnedDate, None)


class TestRepo(unittest.TestCase):
    def test_addElement(self):
        m = Movie('motan', 'the one', 'ioan')
        r = Repository()
        r.addElement(m)
        self.assertEqual(len(r), 1)

    def test_ID(self):
        c = Client('grigore')
        r = Repository()
        r.addElement(c)
        self.assertEqual(r.IDinRepo(c.ID), c)
        self.assertEqual(r.IDinRepo(0), None)
        self.assertNotEqual(r.IDinRepo(c.ID), None)
        self.assertEqual(r.IDinRepo(0), None)

    def test_getRepoList(self):
        r = Repository()
        r.addElement(Client('andrei'))
        r.addElement(Client('ion'))
        self.assertEqual(len(r), 2)
        self.assertEqual(r[0].clientName, 'andrei')
        self.assertEqual(r[1].clientName, 'ion')

    def test_removeElement(self):
        r = Repository()
        c = Client('hons')
        r.addElement(c)
        r.removeElement(c.ID)
        self.assertEqual(len(r), 0)


class test_Service(unittest.TestCase):
    pass
