from userInterface import *

while (boardDim:=get_Board_Dimensions()) is None:
    continue
board = Board(boardDim[0], boardDim[1])
computer = Computer(board)
game = Game(board, computer)
UI = UserInterface(game)
UI.start()
