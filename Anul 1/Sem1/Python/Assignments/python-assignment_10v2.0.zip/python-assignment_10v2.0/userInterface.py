from domain import *


def get_Board_Dimensions():
    try:
        row = int(input("Rows: ").strip())
        col = int(input("Cols: ").strip())
        assert row > 5 and col > 5
        return (row, col)
    except:
        print("Invalid board dimensions. Try again.")


class UserInterface:
    def __init__(self, game):
        self._game = game

    @property
    def game(self):
        return self._game

    def _get_move(self):
        '''
        Get a valid move input.
        '''
        try:
            move = [int(x) for x in input("Coordinates:> ").strip().split(" ")]
            assert len(move) == 2
            return move
        except:
            raise GameError("The 2 coordinates should be integers")

    def start(self):
        print("Player: 'X'\nComputer: 'O'\n")

        try:
            move = self._get_move()
            self.game.playerMove(move[0], move[1])
            self.game.computerMove()

            while not self.game.board.won(move[0], move[1]) and not self.game.board.tie():
                try:
                    print(self.game.board)
                    move = self._get_move()
                    self.game.playerMove(move[0], move[1])
                    self.game.computerMove()
                except GameError as error:
                    print(error)
                except ComputerError as computerWon:
                    print(self.game.board)
                    print(computerWon)
                    exit()

            if self.game.board.tie():
                print(self.game.board)
                print("It's a draw.")
            else:
                print(self.game.board)
                print("Congrats! You won :]")
        except GameError as error:
            print(error)
