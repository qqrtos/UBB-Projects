from texttable import Texttable
from random import randint


class GameError(Exception):
    '''
    Custom error for my game.
    '''

    def __init__(self, message):
        super().__init__(message)


class Board:
    def __init__(self, rows, columns):
        self._rows = rows
        self._columns = columns
        self._board = self._initBoard()
        self._moves = 0

    def _initBoard(self):
        board = []
        for i in range(self.rows):
            board.append([0] * self.columns)
        return board

    @property
    def board(self):
        return self._board

    @property
    def columns(self):
        return self._columns

    @property
    def rows(self):
        return self._rows

    def __str__(self):
        '''
        Transform the board into a table drawable in the console.
        '''
        t = Texttable()
        d = {0: ' ', 1: 'X', -1: 'O'}
        for row in self.board:
            toDraw = []
            for element in row:
                toDraw += d[element]
            t.add_row(toDraw)
        return (t.draw() + '\n')

    def _squareTaken(self, row, col):
        '''
        Check whether the square with coordinates (row, col) is taken.
        '''
        return self.board[row][col] != 0

    def move(self, row, col, player):
        '''
        Make a valid move on the board
        '''
        if row >= self.rows or col >= self.columns or row < 0 or col < 0:
            raise GameError("Move outside the board.")

        if self._squareTaken(row, col):
            raise GameError("Square already taken.")

        d = {'P': 1, 'C': -1}
        self._moves += 1
        self._board[row][col] = d[player]

    def won(self, row, col):
        '''
        Return True if someone won. False otherwise.
        '''
        # sum of values on the same line
        if col < 4:
            minCol = 0
        else:
            minCol = col - 4
        maxCol = self.columns - 5
        for column in range(minCol, maxCol + 1):
            # calculates the sum for each set of 5 consecutive elements (on row 'row') that contain square (r, c)
            lineSum = 0
            for i in range(5):
                lineSum += self.board[row][column + i]
            if abs(lineSum) == 5:
                return True

        # sum of the values on the same column
        if row < 4:
            minRow = 0
        else:
            minRow = row - 4
        maxRow = self.rows - 5
        for eachRow in range(minRow, maxRow + 1):
            # calculates the sum for each set of 5 consecutive elements (on column 'col') that contain square (r, c)
            colSum = 0
            for i in range(5):
                colSum += self.board[eachRow + i][col]
            if abs(colSum) == 5:
                return True

        # minRow and minCol are already determined
        while minRow != maxRow and minCol != maxCol:
            diagSum = 0
            for i in range(5):
                diagSum += self.board[minRow + i][minCol + i]
            if abs(diagSum) == 5:
                return True
            minRow += 1
            minCol += 1

        return False  # no one won yet

    def tie(self):
        return self._moves == (self.columns * self.rows)


class ComputerError(Exception):
    def __init__(self, message):
        super().__init__(message)


class Computer:
    def __init__(self, board):
        self._board = board

    @property
    def board(self):
        return self._board

    def isWin(self, player):
        '''
        Decides whether 'player' can win in 1 move.
        Returns the coordinates of the winning move.
        '''
        # This function is used to make the computer win in 1 move (if possible) or prevent the player from winning.
        d = {'P': 1, 'C': -1}
        for i in range(self.board.rows):
            for j in range(self.board.columns):
                if self.board._squareTaken(i, j) != True:
                    savedPosition = self.board._board[i][j]
                    self.board._board[i][j] = d[player]
                    if self.board.won(i, j):
                        self.board._board[i][j] = 0
                        return (i, j)
                    self.board._board[i][j] = savedPosition
        return None

    def giveCoordinates(self):
        '''
        Returns random coordinates for the computer.
        '''
        col = randint(0, self._board.columns - 1)
        row = randint(0, self._board.rows - 1)
        while self._board._squareTaken(row, col):
            col = randint(0, self._board.columns - 1)
            row = randint(0, self._board.rows - 1)
        return (row, col)


class Game:
    def __init__(self, board, computer):
        self._board = board
        self._computer = computer

    @property
    def board(self):
        return self._board

    @property
    def computer(self):
        return self._computer

    def playerMove(self, row, col):
        self.board.move(row, col, 'P')

    def computerMove(self):
        '''
        Gets the coordinates for the optimal move (for the computer) and makes it.
        '''
        coords = self.computer.isWin('C')
        if coords is None:
            coords = self.computer.isWin('P')
            if coords is None:
                coords = self.computer.giveCoordinates()
        self.board.move(coords[0], coords[1], 'C')
        if self.board.won(coords[0], coords[1]) is True:
            raise ComputerError("Computer won :]")
