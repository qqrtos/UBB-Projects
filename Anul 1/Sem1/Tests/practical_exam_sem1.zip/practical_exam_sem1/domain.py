from texttable import Texttable
import random


class GameError(Exception):
    def __init__(self, msg):
        super().__init__(msg)


class Board:
    # 0 -> ' '
    # 1 -> E
    # 2 -> *
    # -1 -> B
    def __init__(self):
        self._loadBoard()
        self._placeStars()
        self._placeEndeavor()
        self._placeBlingon()

    @property
    def board(self):
        return self._board

    def _loadBoard(self):
        self._board = []
        for i in range(8):
            self._board.append([0] * 8)

    def isTaken(self, row, col):
        '''
        Return the status of a square
        :param row: the row
        :param col: the column
        :return: True -> Square is empty, False otherwise
        '''
        return self.board[row][col] != 0

    def _hasAdjacent(self, row, col):
        '''
        Checks whether a square has any neighbours that are not empty.
        :param row: row index
        :param col: column index
        :return: True -> square has a neighbour, False otherwise
        '''
        if row < 7 and self.board[row + 1][col] != 0:
            return True
        if col < 7 and self.board[row][col + 1] != 0:
            return True
        if row > 0 and self.board[row - 1][col] != 0:
            return True
        if col > 0 and self.board[row][col - 1] != 0:
            return True
        if col < 7 and row < 7 and self.board[row + 1][col + 1] != 0:
            return True
        if col > 0 and row > 0 and self.board[row - 1][col - 1] != 0:
            return True
        if col > 0 and row < 7 and self.board[row + 1][col - 1] != 0:
            return True
        if col < 7 and row > 0 and self.board[row - 1][col + 1] != 0:
            return True
        return False

    def move(self, row, col, symbol):
        '''
        Make a move on the board
        :param symbol: place a star, a ship or a Blingon
        :return:
        '''
        symbolDict = {'E': 1, '*': 2, 'B': -1, ' ': 0}
        if row > 7 or col > 7 or row < 0 or col < 0:
            raise GameError("Move outside the board")
        if self.isTaken(row, col):
            raise GameError("Square is taken.")
        self._board[row][col] = symbolDict[symbol]

    def _placeStars(self):
        '''
        Place 10 stars on the grid. Positions are chosen randomly.
        :return: -
        '''
        for i in range(10):
            col = random.randint(0, 7)
            row = random.randint(0, 7)
            while self.isTaken(row, col) == True or self._hasAdjacent(row, col) == True:
                col = random.randint(0, 7)
                row = random.randint(0, 7)

            self.move(row, col, '*')

    def isNearEndeavor(self, row, col):
        '''
        Checks whether the square from [row, col] has a neighbour endeavor.
        :return:
        '''
        if row < 7 and self.board[row + 1][col] == 1:
            return True
        if col < 7 and self.board[row][col + 1] == 1:
            return True
        if row > 0 and self.board[row - 1][col] == 1:
            return True
        if col > 0 and self.board[row][col - 1] == 1:
            return True
        if col < 7 and row < 7 and self.board[row + 1][col + 1] == 1:
            return True
        if col > 0 and row > 0 and self.board[row - 1][col - 1] == 1:
            return True
        if col > 0 and row < 7 and self.board[row + 1][col - 1] == 1:
            return True
        if col < 7 and row > 0 and self.board[row - 1][col + 1] == 1:
            return True
        return False

    def _placeBlingon(self):
        for i in range(3):
            col = random.randint(0, 7)
            row = random.randint(0, 7)
            while self.isTaken(row, col) == True:
                col = random.randint(0, 7)
                row = random.randint(0, 7)

            self.move(row, col, 'B')

    def _placeEndeavor(self):
        col = random.randint(0, 7)
        row = random.randint(0, 7)
        while self.isTaken(row, col) == True:
            col = random.randint(0, 7)
            row = random.randint(0, 7)

        self.move(row, col, 'E')

    def getEndeavorPosition(self):
        for i in range(8):
            for j in range(8):
                if self.board[i][j] == 1:
                    return (i, j)

    def cheat(self):
        table = Texttable()
        table.add_row(['0', '1', '2', '3', '4', '5', '6', '7', '8'])
        coordsLine = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']
        symbolDict = {0: ' ', 1: 'E', 2: '*', -1: 'B'}
        for i in range(8):
            newRow = [coordsLine[i]]
            for j in range(8):
                newRow.append(symbolDict[self._board[i][j]])
            table.add_row(newRow)
        return table.draw()

    def __str__(self):
        table = Texttable()
        table.header(['0', '1', '2', '3', '4', '5', '6', '7', '8'])
        coordsLine = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']
        symbolDict = {0: ' ', 1: 'E', 2: '*', -1: ' '}
        for i in range(8):
            newRow = [coordsLine[i]]
            for j in range(8):
                if self.board[i][j] == -1 and self.isNearEndeavor(i, j):
                    newRow.append('B')
                else:
                    newRow.append(symbolDict[self.board[i][j]])
            table.add_row(newRow)
        return table.draw()


class GameOver(Exception):
    def __init__(self, msg):
        super().__init__(msg)


class Game:
    def __init__(self, board):
        self._board = board

    @property
    def board(self):
        return self._board

    def warp(self, row, col):
        endeavorRow, endeavorCol = self.board.getEndeavorPosition()
        if col > 7 or col < 0:
            raise GameError("Move outside the board.")
        if row > 7 or row < 0:
            raise GameError("Move outside the board.")
        # if row not in [endeavorRow - 1, endeavorRow + 1, endeavorRow]:
        #     raise GameError("Move is not valid.")
        # if col not in [endeavorCol - 1, endeavorCol + 1, endeavorCol]:
        #     raise GameError("Move is not valid.")
        if row != endeavorRow and col != endeavorCol:
            endeavorRow, endeavorCol = self.board.getEndeavorPosition()
            ok = False
            for i in range(7):
                if endeavorRow - i >= 0 and endeavorCol - i >= 0 and endeavorRow - i == row and endeavorCol - i == col:
                    ok = True
                if endeavorRow + i <= 7 and endeavorCol + i <= 7 and endeavorRow + i == row and endeavorCol + i == col:
                    ok = True
                if endeavorRow - i >= 0 and endeavorCol + i <=7 and endeavorRow - i == row and endeavorCol + i == col:
                    ok = True
                if endeavorRow + i <= 7 and endeavorCol + i >= 0 and endeavorRow + i == row and endeavorCol - i == col:
                    ok = True
            if ok==False:
                raise GameError("Not on the same line/col/diag.")
        if self.board.board[row][col] == 2:
            raise GameError("Star is in the way.")
        if self.board.board[row][col] == -1:
            raise GameOver("You landed on a Blingon! GAME OVER!")
        self.board._board[endeavorRow][endeavorCol] = 0
        self.board.move(row, col, 'E')

    def fire(self, row, col):
        endeavorRow, endeavorCol = self.board.getEndeavorPosition()
        if col > 7 or col < 0:
            raise GameError("Cannot fire outside the board.")
        if row > 7 or row < 0:
            raise GameError("Cannot fire outside the board.")
        if row not in [endeavorRow - 1, endeavorRow + 1, endeavorRow]:
            raise GameError("Too far.")
        if col not in [endeavorCol - 1, endeavorCol + 1, endeavorCol]:
            raise GameError("Too far.")
        if self.board.board[row][col] == 2:
            raise GameError("Cannot shoot a star.")
        if self.board.board[row][col] == -1:
            self.board._board[row][col] = 0
            self.board._placeBlingon()

    def isWon(self):
        for i in range(8):
            for j in range(8):
                if self.board.board[i][j] == -1:
                    return False
        raise GameOver("You won!!!")

    def cheat(self):
        return self.board.cheat()
