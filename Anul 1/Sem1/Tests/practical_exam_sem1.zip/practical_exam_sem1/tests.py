from domain import *
import unittest


class test_stars(unittest.TestCase):
    def test_isTaken(self):
        board = Board()
        board._board = [[0, 0, 0], [1, 1, 0]]
        self.assertEqual(board.isTaken(1, 0), True)
        self.assertEqual(board.isTaken(0, 0), False)

    def test_hasAdjacent(self):
        board = Board()
        board._board = [[0, 0, 0, 0, 1, 0, 0], [1, 1, 0, 0, 0, 1, 0], [0, 0, 0, 0, 1, 0, 0], [0, 0, 0, 0, 1, 0, 0],
                        [0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0]]
        self.assertEqual(board._hasAdjacent(0, 0), True)
        self.assertEqual(board._hasAdjacent(1, 1), True)
        self.assertEqual(board._hasAdjacent(5, 5), False)

    def test_move(self):
        board = Board()
        board._board = [[0, 0, 0, 0, 1, 0, 0], [1, 1, 0, 0, 0, 1, 0], [0, 0, 0, 0, 1, 0, 0], [0, 0, 0, 0, 1, 0, 0],
                        [0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0], [0, 0, 0, 0, 0, 0, 0]]
        board.move(6, 6, '*')
        self.assertEqual(board.board[6][6], 2)
        try:
            board.move(0, 4, '*')
            assert False
        except GameError:
            assert True

    def test_placeStars(self):
        board = Board()
        current = 0
        for i in range(8):
            for j in range(8):
                if board.board[i][j] == 2:
                    current += 1
        self.assertEqual(current, 10)
