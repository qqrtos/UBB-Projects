from domain import *


class UserInterface:
    def __init__(self, game):
        self._game = game

    @property
    def game(self):
        return self._game

    def _parseInput(self, text):
        commandTuple = text.split(' ')
        cmd = commandTuple[0]
        params = commandTuple[1]
        return (cmd, params)

    def validateParameters(self, params):
        rows = {'A': 0, 'B': 1, 'C': 2, 'D': 3, 'E': 4, 'F': 5, 'G': 6, 'H': 7}
        try:
            row = rows[params[0]]
            col = int(params[1]) - 1
            return (row, col)
        except:
            raise GameError("Invalid parameters.")

    def warp(self, row, col):
        self.game.warp(row, col)

    def fire(self, row, col):
        self.game.fire(row, col)

    def cheat(self):
        print(self.game.cheat())

    def start(self):
        commands = {'warp': self.warp, 'cheat': self.cheat, 'fire': self.fire}

        while True:
            print(self.game.board)
            option = input("> ").strip()
            try:
                if option == 'cheat':
                    self.cheat()
                    continue

                cmd, params = self._parseInput(option)

                if cmd in commands.keys():
                    try:
                        row, col = self.validateParameters(params)
                        commands[cmd](row, col)
                    except GameError as GE:
                        print(GE)
                    except GameOver as over:
                        print(over)
                        return
                else:
                    print("Invalid command.")
            except:
                print("Invalid command!")


board = Board()
game = Game(board)
UI = UserInterface(game)
UI.start()
