from service import *


def initCoffeeList(coffeeList):
    coffeeList.append(['Latte', 'Poland', 9.99])
    coffeeList.append(['Frappe', 'France', 4.50])
    coffeeList.append(['Espresso', 'France', 2.00])
    coffeeList.append(['Mol Classic', 'Romania', 0.99])
    coffeeList.append(['Starbucks', 'Spain', 7.99])


def printOptions():
    print("\n\t1. Add a ccoffee.")
    print("\t2. Print all coffees (sorted).")
    print("\t3. Filter coffees.")
    print("\t4. Delete coffees from a country.")
    print("\t5. Exit.")


def addCoffee_UI(coffeList):
    name = input("Name: ")
    origin = input("Origin: ")
    price = input("Price: ")
    addCoffee_service(coffeeList, name, origin, price)


'''!!!!!!!!!!'''
def listCoffees_UI(coffeeList):
    sortedList = sorted(coffeeList, key=lambda x: x[1])
    for c in sortedList:
        print("Name: " + str(c[0]), "\t\tOrigin: " + str(c[1]), "\t\tPrice: " + str(c[2]))


def filterCoffee_UI(coffeeList):
    orig = input("Origin: ")
    price = input("Price: ")
    filteredList = []
    if orig == '':
        filteredList = filterCoffee_service(coffeeList, price=price)
    elif price == '':
        filteredList = filterCoffee_service(coffeeList, origin=orig)
    else:
        filteredList = filterCoffee_service(coffeeList, orig, price)
    if len(filteredList) == 0:
        print("No such coffees.")
    else:
        listCoffees_UI(filteredList)


def deleteCoffee_UI(coffeeList):
    origin = input("Origin: ")
    deleteCoffee_service(coffeeList, origin)


def start(coffeeList):
    commands = {
        '1': addCoffee_UI,
        '2': listCoffees_UI,
        '3': filterCoffee_UI,
        '4': deleteCoffee_UI
    }
    while True:
        printOptions()
        opt = input("Option:> ")
        if opt in commands.keys():
            try:
                commands[opt](coffeeList)
            except Exception as e:
                print(e)
        elif opt == '5':
            break
        else:
            print("Invalid command.")


coffeeList = []
initCoffeeList(coffeeList)
start(coffeeList)
