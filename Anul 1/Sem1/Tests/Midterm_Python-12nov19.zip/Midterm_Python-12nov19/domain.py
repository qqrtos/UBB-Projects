def createCoffee(name, origin, price):
    return [name, origin, price]


def test_createCoffee():
    c = createCoffee('Cafea', 'Spain', 3.99)
    assert c == ['Cafea', 'Spain', 3.99]


test_createCoffee()
