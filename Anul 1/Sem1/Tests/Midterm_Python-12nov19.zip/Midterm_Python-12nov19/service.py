from domain import *


def addCoffee_service(coffeeList, name, origin, price):
    try:
        price = float(price)
        if price <= 0:
            assert False
    except:
        raise Exception("Price should be a float greater than 0.")
    for c in coffeeList:
        if c[0] == name:
            raise Exception("Coffe name should be unique.")
    coffeeList.append(createCoffee(name, origin, price))


def test_addCoffee_service():
    l = []
    c = createCoffee('cafea', 'romania', 4.99)
    addCoffee_service(l, 'cafea', 'romania', '4.99')
    assert len(l) == 1
    assert c == l[0]
    try:
        addCoffee_service(l, 'cafea', 'romania', '-5.99')
        assert len(l) == 1
    except:
        assert True
    try:
        addCoffee_service(l, 'cafea', 'spain', '5.90')
        assert len(l) == 1
    except:
        assert True


test_addCoffee_service()


def filterCoffee_service(coffeeList, origin=None, price=None):
    filteredList = []
    if origin == None:
        price = float(price)
        for c in coffeeList:
            if c[-1] <= price:
                filteredList.append(c)
        return filteredList
    elif price == None:
        for c in coffeeList:
            if c[1] == origin:
                filteredList.append(c)
        return filteredList
    else:
        price = float(price)
        for c in coffeeList:
            if c[1] == origin and c[-1] <= price:
                filteredList.append(c)
        return filteredList


def test_filterCoffee_service():
    l = [['Cafea', 'Romania', 4.99], ['Coof', 'Romania', 6.99], ['Starch', 'Denmark', 9.99]]
    assert filterCoffee_service(l, 'Romania', 7.00) == [['Cafea', 'Romania', 4.99], ['Coof', 'Romania', 6.99]]
    assert filterCoffee_service(l, origin='Denmark') == [['Starch', 'Denmark', 9.99]]
    assert filterCoffee_service(l, price=10) == [['Cafea', 'Romania', 4.99], ['Coof', 'Romania', 6.99],
                                                 ['Starch', 'Denmark', 9.99]]


test_filterCoffee_service()


def deleteCoffee_service(coffeeList, origin):
    i = 0
    while i < len(coffeeList):
        if coffeeList[i][1] == origin:
            coffeeList.remove(coffeeList[i])
            i -= 1
        i += 1


def test_deleteCoffee_service():
    l = [['Cafea', 'Romania', 4.99], ['Coof', 'Hungary', 6.99], ['Starch', 'Romania', 9.99]]
    deleteCoffee_service(l, 'Romania')
    assert len(l) == 1
    deleteCoffee_service(l, 'France')
    assert len(l) == 1
    deleteCoffee_service(l, 'Hungary')
    assert len(l) == 0


test_deleteCoffee_service()
